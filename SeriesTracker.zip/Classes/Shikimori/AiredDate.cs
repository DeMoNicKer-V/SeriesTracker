﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeriesTracker.Classes.Shikimori
{
    public class AiredDate
    {
        public string Date { get; set; }
    }
}
