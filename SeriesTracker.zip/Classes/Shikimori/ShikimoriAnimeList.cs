﻿namespace SeriesTracker.Classes.Shikimori
{
    internal class ShikimoriAnimeList
    {
        public ShikimoriAnime[] Animes { get; set; }
    }
}
